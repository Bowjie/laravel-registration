<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class RegistrationController extends Controller
{
    public function index(){
    	$title = "WELCOME";
    	return view('pages.registration', compact('title'));
    }
}
