<!DOCTYPE html>
<html lang="<?php echo e(app()->getLocale()); ?>">
<head>
	
	<meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
    <title><?php echo e(config('app.name', 'LSAPP')); ?></title>
    <style>
    .label1{
        text-align: center;
        margin-bottom: 50px;
        font-size: 50px;
    }
    .lbl1{
        text-align: right;
        font-size: 20px;
    }
    .drop{
        font-size: 20px;
    }
    body{
        background-image: url(bg.jpg);
        color: white;
        background-attachment: fixed;
        background-repeat: no-repeat;
        background-size: cover;
    }
    .groove {
        border-style: groove;
        margin-top: 20px;
        width: 800px;
        height: 700px;
        border-radius: 20px;
        background: black;
    }
</style>
</head>
<body class="container">

	<div class="container">

    <div class="groove container-fluid">
        <form method="post" action="registration.php">
        <div class="label1 container-fluid">
            <br>
            <p><b>WELCOME</b><p>
        </div>
        <div class="lbl1 col-lg-4">
            <p style="margin-top: 8px;"><b>First Name:</b></p><br>
            <p style="margin-top: 8px;"><b>Surname:</b></p><br>
            <p style="margin-top: 3px;"><b>Section:</b></p><br>
        </div>
        <div class="drop col-lg-8">
            <p><input required type="text" id="FName" name="FName" maxlength="40" style="width: 53%; color:black; text-transform: capitalize"  required></p><br>
            <p><input required type="text" id="LName" name="LName" maxlength="40" style="width: 53%; text-transform: capitalize; color:black" required></p><br>
            <p><select required id="Sec" name="Sec" style="width: 53%; color:black;">
                <option value="" class="sel">--SELECT--</option>
                <option value="BSIT-1A">BSIT-1A</option>
                <option value="BSCS-1A">BSCS-1A</option>
                <option value="BSIT-4A">BSIT-4A</option>
                <option value="BSCS-4A">BSCS-4A</option>
            </select></p><br>
        </div>
        <div class="col-lg-2">
        <center><button type="submit" class="btn btn-success" style="font-size: 20px;">I'm Ready to Enter</button></center>
        </div>

        </form>
      </div>
</div>
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
	<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
</body>
</html>