<?php $__env->startSection('content'); ?>
    <div class="container">

    <div class="groove container-fluid">
        <form method="post" action="registration.php">
        <div class="label1 container-fluid">
            <br>
            <p><b><?php echo e($title); ?></b><p>
        </div>
        <div class="lbl1 col-lg-4">
            <p style="margin-top: 8px;"><b>First Name:</b></p><br>
            <p style="margin-top: 8px;"><b>Surname:</b></p><br>
            <p style="margin-top: 3px;"><b>Section:</b></p><br>
        </div>
        <div class="drop col-lg-8">
            <p><input required type="text" id="FName" name="FName" maxlength="40" style="width: 53%; color:black; text-transform: capitalize"  required></p><br>
            <p><input required type="text" id="LName" name="LName" maxlength="40" style="width: 53%; text-transform: capitalize; color:black" required></p><br>
            <p><select required id="Sec" name="Sec" style="width: 53%; color:black;">
                <option value="" class="sel">--SELECT--</option>
                <option value="BSIT-1A">BSIT-1A</option>
                <option value="BSCS-1A">BSCS-1A</option>
                <option value="BSIT-4A">BSIT-4A</option>
                <option value="BSCS-4A">BSCS-4A</option>
            </select></p><br>
        </div>
        <div class="col-lg-2">
        <center><button type="submit" class="btn btn-success" style="font-size: 20px;">I'm Ready to Enter</button></center>
        </div>

        </form>
      </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>